
// g++ --std=c++11 test.cpp

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

#include "doctest.h"
#include "ui.h"

#include "namespace.h"
FASTLED_USING_NAMESPACE

TEST_CASE("compile ui test") {
}


